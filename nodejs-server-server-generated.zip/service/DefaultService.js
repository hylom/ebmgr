'use strict';


/**
 * Returns all books list
 *
 * returns List
 **/
exports.booksGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "path" : "/foo/bar/baz",
  "name" : "some interesting title"
}, {
  "path" : "/foo/bar/baz",
  "name" : "some interesting title"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


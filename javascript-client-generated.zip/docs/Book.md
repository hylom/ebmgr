# EbookManagerEbmgrApp.Book

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | name of book | [optional] 
**path** | **String** | virtualized path of book | [optional] 
